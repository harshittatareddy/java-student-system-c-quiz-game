#include <stdio.h>
#include <string.h>
#include <ctype.h>

struct Question {
    char question[256];
    char options[4][100];
    char correct;
};

void askQuestion(struct Question q, int *score) {
    char answer;

    printf("\n%s\n", q.question);
    for (int i = 0; i < 4; i++) {
        printf("%c. %s\n", 'A' + i, q.options[i]);
    }

    printf("Enter your answer (A/B/C/D): ");
    scanf(" %c", &answer);

    if (toupper(answer) == q.correct) {
        printf("Correct!\n");
        (*score)++;
    } else {
        printf("Wrong! Correct answer is %c\n", q.correct);
    }
}

int main() {
    struct Question quiz[3] = {
        {
            "What is the capital of India?",
            {"Delhi", "Mumbai", "Kolkata", "Chennai"},
            'A'
        },
        {
            "Which language is used in C programming?",
            {"Java", "Python", "C", "Ruby"},
            'C'
        },
        {
            "Who is the founder of Microsoft?",
            {"Elon Musk", "Steve Jobs", "Bill Gates", "Sundar Pichai"},
            'C'
        }
    };

    int score = 0;

    printf("==== Welcome to the Quiz Game ====\n");

    for (int i = 0; i < 3; i++) {
        askQuestion(quiz[i], &score);
    }

    printf("\nYour Final Score: %d out of 3\n", score);
    return 0;
}
